Page({
  data: {
    usernickName: '',
    avatarUrl: '',
    iden:'未认证'
  },

  onLoad: function (options) {
    wx.getUserInfo({
      success: res => {
        console.log(res.userInfo)
        this.setData({
          usernickName: res.userInfo.nickName,
          avatarUrl: res.userInfo.avatarUrl
        })
      },
      fail: err => {
        console.log(err.errMsg)
      }
    })
  },
  click_Message: function () {
    wx: wx.navigateTo({
      url: '../Mymessage/Mymessage',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  click_iden: function () {
    wx: wx.navigateTo({
      url: '../identy/identy',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  click_QQgroup: function () {
    wx: wx.navigateTo({
      url: '../QQgroup/QQgroup',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  click_Like: function () {
    wx: wx.navigateTo({
      url: '../Like/Like',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  click_Couple_back: function () {
    wx: wx.navigateTo({
      url: '../couple_back/couple_back',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  click_About_us: function () {
    wx: wx.navigateTo({
      url: '../about_us/about_us',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  click_Set: function () {
    wx: wx.navigateTo({
      url: '../setting/setting',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  onReady: function () {

  },

  onShow: function () {

  },

  onHide: function () {

  },

  onUnload: function () {

  },

  onPullDownRefresh: function () {

  },

  onReachBottom: function () {

  },


  onShareAppMessage: function () {

  }
})